/*------------------------------------------------------------[]
 /* Centro Universitario Senac - 1o semestre 2017                        
 /* Projeto Integrador II
 /* Nomes : Israel Barros                           
 /*         Mauro Costa   
 /*         Paulo Navarro
 /*------------------------------------------------------------[]
 
 TROCAR O ENDERECO DO ARQUIVO "Contatos.txt" NO METODO "lerDoArquivo" ANTES DE EXECUTAR
 */


//importa os metodos a serem utilizados
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

class Agenda {
  //cria um vetor da classe contatos.
  Contato [] agenda = new Contato[10];
  
  //insere elementos os elementos na classe contato
  Contato criarContato(){
    Contato novoContato = new Contato();
    Scanner sc = new Scanner(System.in);
    
    System.out.println("Digite o nome do contato: ");
    novoContato.setNome(sc.nextLine());
    
    System.out.println("Digite o sobrenome do contato: ");
    novoContato.setSobrenome(sc.nextLine());
    
    System.out.println("Digite o endereco do contato: ");
    novoContato.setEndereco(sc.nextLine());
    
    System.out.println("Digite o e-mail do contato: ");
    novoContato.setEmail(sc.nextLine());
    
    System.out.println("Digite o numero de celular do contato: ");
    novoContato.setTelCelular(sc.nextLine());
    
    System.out.println("Digite a data de aniversario do contato: ");
    novoContato.setAniversario(sc.nextLine());
    
    return novoContato;
  }
  
  
  void inserirContato(){
    
    Contato novoContato = this.criarContato();
    //esse laco verifica se ha espaco na agenda, caso sim insere novo contato
    for(int i =0; i < agenda.length; i++ )
      if (agenda[i] == null){
      agenda[i] = novoContato;
      return;
    }  
    System.out.println("A agenda esta cheia"); 
  }
  
  
  void inserirContatoNoInicio(){
    Contato novoContato = this.criarContato();
    
    boolean cheio = true;
    int x = 0;
    Contato aux;
    
    //procura se ha espaco na agenda
    for(int i = 0; i < agenda.length; i++)
      if(agenda[i] == null){
      cheio = false;
      //x recebe o espaco disponivel
      x = i;
      break;
    }
    
    if(cheio == true)
      System.out.println("A agenda esta cheia");
    
    //se estiver espaco, ele joga os elementos para direita
    
    else if(cheio == false)
      //i recebe espaço nulo e o laco percorre o vetor substituindo os elementos.
      for(int i = x; i >= 0; i--)
      for(int j = i-1; j >= 0; j--)
      if(agenda[i] == null){
      aux = agenda[i];
      agenda[i] = agenda[j];
      agenda[j] = aux;
    }   
    
    agenda[0] = novoContato;   
  }
  
  boolean excluirContato(){
    Scanner sc = new Scanner(System.in);
    
    System.out.println("Qual contato vc deseja excluir: ");
    int num = sc.nextInt() - 1;
    
    int x = 0;
    Contato aux;
    
    //contador para verificar se a agenda esta vazia
    for(int i = 0; i < agenda.length; i++)
      if(agenda[i] == null)
      x++;
    
    //se x for igual tamanho da agenda o vetor esta cheio
    if(x == agenda.length){
      System.out.println("A agenda esta vazia");
      return false;
    } 
    
    //verifica se ha algum contato na posicao informada
    else if(agenda[num] == null){
      System.out.println("Nao ha contatos na posicao "+ (num + 1) +" da agenda");
      return false;
    } 
    
    else{
      //exclui o contato informado e joga os seguintes para esquerda
      agenda[num] = null;
      // i recebe o numero do contato a ser excluido e ordena o vetor
      for(int i = num; i < agenda.length-1 ; i++)
        for(int j = i+1; j < agenda.length; j++)
        if (agenda[i] == null){
        aux = agenda[i];
        agenda[i] = agenda[j];
        agenda[j] = aux;
      }
    }
    // retorna True se o contato foi excluido com sucesso
    return true;
  }
  
  void consultarContato(){
    Scanner sc = new Scanner(System.in);
    
    System.out.println("Qual contato vc deseja consultar: ");
    int num = sc.nextInt() - 1;
    
    //verifica se o ha algum contato no indice informado
    if(agenda[num] == null)
      System.out.println("Contato vazio");
    
    // caso encontre o contato ele sera mostrado
    else
      imprimePorIndice(num);
    
  }
  
  //metodo auxiliar para imprimir a agenda por indice
  void imprimePorIndice(int i){
    
    System.out.println(" --- Contato " + (i+1)+ " ---");
    System.out.println("Nome: "+ agenda[i].getNome());
    System.out.println("Sobrenome: "+ agenda[i].getSobrenome());
    System.out.println("Endereco: " + agenda[i].getEndereco());
    System.out.println("E-mail: "+ agenda[i].getEmail());
    System.out.println("Numero do celular: "+ agenda[i].getTelCelular());
    System.out.println("Data de aniversario: "+ agenda[i].getAniversario());
  }
  
  void substituirContato(){
    Scanner sc = new Scanner(System.in);
    
    System.out.println("Qual contato vc deseja substituir: ");
    int num = sc.nextInt() - 1;
    
    //verifica se ha algum contato no indice informado
    if(agenda[num] == null){
      System.out.println("Nao existe nenhum contato neste indice");
      System.out.println("Entre com um novo contato: ");      
      agenda[num] = this.criarContato();      
    }    
    //caso nao, ele ja insere um novo
    else if(agenda[num] != null){
      agenda[num] = this.criarContato();
    }
    
  }
  
  void contatosComTermo(){
    Scanner sc = new Scanner(System.in);
    
    System.out.println("Digite o nome que procura: ");
    String  letra = sc.next();
    
    
    boolean encontrou = false;
    
    //procura o contato pela letra informada pelo usuario usando metodo contains
    for(int i = 0; i < agenda.length; i++)
      //verifica se ha algum contato contendo a string informada
      if( (agenda[i] != null) && (agenda[i].getNome().contains(letra)) ){
      imprimePorIndice(i);
      encontrou = true;
    }
    
    //caso nao encontre ele informa ao usuario
    if(encontrou != true)
      System.out.println("Nao foi encontrado"); 
  }
  
  void imprimirAgenda(){
    for(int i = 0; i < agenda.length; i++ ){
      //se encontrar um contato vazio informa o usuario
      if (agenda[i] == null){
        System.out.println(" --- Contato " + (i+1)+ " ---");
        System.out.println("Vazio");
      }
      else{
        System.out.println();
        System.out.println(" --- Contato " + (i+1)+ " ---");
        System.out.println("Nome: "+ agenda[i].getNome());
        System.out.println("Sobrenome: "+ agenda[i].getSobrenome());
        System.out.println("Endereco: " + agenda[i].getEndereco());
        System.out.println("E-mail: "+ agenda[i].getEmail());
        System.out.println("Numero do celular: "+ agenda[i].getTelCelular());
        System.out.println("Data de aniversario: "+ agenda[i].getAniversario());
      }
    }
  }
  
  
  int quantidadeElementos(){
    int aux = 0;
    //conta quantos contatos foram criados ate o momento
    for(int i =0; i < agenda.length; i++ )
      if (agenda[i] != null)
      aux++;
    
    System.out.println("A agenda tem " +aux+ " contato(s) criado(s).\n");
    return aux;
  }
  
  
  int capacidadeAgenda(){
    int aux = 0;
    //percorre o vetor procurando contatos vazios
    for(int i =0; i < agenda.length; i++ )
      if (agenda[i] == null)
      aux++;
    
    if (aux != 0)
      System.out.println("A agenda tem " +aux+ " contato(s) disponivel(eis) para serem criados.\n");
    
    else if (aux == 0)
      System.out.println("A agenda nao tem contatos vazios");
    
    
    return aux;
  }
  
  
  void ordenaAgenda(){
    Contato aux;
    //usa o metodo 'compareToIgnoreCase' para ordenar contatos de ordem alfabetica. 
    //IgnoreCase ignorara letras maiusculas tranformando em minusculas
    //se agenda[i] > 0, ela assumira a promeira posicao
    
    for (int i = 0; i < agenda.length-1; i++) 
      for (int j = i+1; j < agenda.length; j++) 
      if ((agenda[j] != null) &&  (agenda[i] != null) && (agenda[i].getNome().compareToIgnoreCase(agenda[j].getNome()) > 0) ){
      aux = agenda[i];
      agenda[i] = agenda[j];
      agenda[j] = aux;
    }
  }
  
  
  void lerDoArquivo(){
    // try/catch e um metodo para tratamento de erros
    try{
      //procura txt no caminho do arquivo
      FileReader fr = new FileReader("/Users/paulo.lnesilva/Desktop/Contatos.txt");
      //le o arquivo informado
      BufferedReader lerArquivo = new BufferedReader(fr);
      
      String linha;
      String [] texto;
      int i =0;
      
      //enquanto a proxima linha for diferente de null e agenda tiver espacos disponiveis   
      while ( ((linha = lerArquivo.readLine()) != null) && (i < agenda.length) ){
        if (linha.isEmpty())
          continue;
        //metodo split faz referencia a formatacao do txt, os dados sao separados por ';'
        texto = linha.split(";");
        
        Contato novoContato = new Contato();
        //insere dados do arquivo no vertor substuindo os valores antigos
        novoContato.setNome(texto[0]);
        novoContato.setSobrenome(texto[1]);
        novoContato.setEndereco(texto[2]);
        novoContato.setEmail(texto[3]);
        novoContato.setTelCelular(texto[4]);
        novoContato.setAniversario(texto[5]);
        agenda[i++] = novoContato;
      }
      
      System.out.println("Lido com sucesso!!!!!!!!");
      lerArquivo.close();
    }
    //caso haja erro o try/catch informa a mensagem de erro
    catch(IOException erro){
      System.out.println("Erro na abertura do aquivo: " + erro);
    }  
  }
  
  //menu visual do usuario
  void menuDoUsuario(){
    System.out.println(" ---------------------- MENU DO USUARIO ---------------------- \n");
    System.out.println("Selecione um item abaixo: \n");
    
    System.out.println("1 - Incluir elementos na proxima posicao disponivel da agenda.");
    System.out.println("2 - Incluir elementos no inicio da agenda.");
    System.out.println("3 - Exclusao de elementos na agenda.");
    System.out.println("4 - Consultar o contato de um indice da agenda.");
    System.out.println("5 - Consultar o contato pelo nome.");
    System.out.println("6 - Substituir o contato de um indice da agenda.");
    System.out.println("7 - Impressao de todos os contatos da agenda.");
    System.out.println("8 - Impressao da quantidade de contatos inseridos.");
    System.out.println("9 - Impressao da capacidade total de contatos disponiveis.");
    System.out.println("10 - Ordenacao ascendente pelo nome.");
    System.out.println("11 - Ler de arquivo.");
    System.out.println("12 - Sair.");
  }
  
  public static void main(String [] args){
    //inicia metodo agenda para chamar metodos
    Agenda exe = new Agenda();
    
    Scanner sc = new Scanner(System.in);
    
    exe.menuDoUsuario();
    
    System.out.println();
    
    int select = sc.nextInt();
    
    //executa o menu do usuario ate ele digitar (12) para sair
    while(select != 12) {
     
      if ((select < 1) || (select > 12))
        System.out.println(select+" nao é uma opcao valida, tente novamente");
      
      switch (select){
        
        case 1:        
          exe.inserirContato();
          break;
          
        case 2:
          exe.inserirContatoNoInicio();
          break;
          
        case 3:
          exe.excluirContato();
          break;
          
        case 4:
          exe.consultarContato();
          break;
          
        case 5:
          exe.contatosComTermo();
          break;
          
        case 6:
          exe.substituirContato();
          break;
          
        case 7:
          exe.imprimirAgenda();
          break;
          
        case 8:
          exe.quantidadeElementos();
          break;
          
        case 9:
          exe.capacidadeAgenda();
          break;
          
        case 10:
          exe.ordenaAgenda();
          break;
          
        case 11:
          exe.lerDoArquivo();
          break;
          
        default:
          select = 12;
          
      }
      

      
      exe.menuDoUsuario();
      System.out.println();
      select = sc.nextInt();
    }    
  }
}